# Exexrcice 1 -> Media Queries

## - Pour des écrans plus grands que 1024px la couleur de fond du body est rouge

## - Pour des écrans entre 600px et 1024px la couleur de fond du body est blue

## - Pour des écrans ntre 320px et 600px la couleur de fond du body est verte